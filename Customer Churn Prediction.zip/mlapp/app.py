
import streamlit as st
import pickle
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.preprocessing import StandardScaler

# LOADING THE MODEL
model = pickle.load(open('churn_pred_2022.pkl','rb'))



def main():

    st.set_page_config(layout="wide")
    # Giving a title
    html_temp = """ 
            <div style = "background-color: orange; padding: 8px">
            <h2 style="color: white; text-align: center">TELECOM CUSTOMER CHURN PREDICTION</h2>
            </div>
            """
    st.markdown(html_temp, unsafe_allow_html=True)
    image = Image.open('4.jpeg')
    st.image(image,'')
    
    st.sidebar.info('This app is developed to predict whether certain Telecom Customers are likely to leave the company something called "churn" or they will retain by making use of Online Prediction or Batch Prediction operational use case.')

    add_selectbox = st.sidebar.selectbox('Select Method of Prediction', ("Select Options","Batch Prediction","Online Prediction", "Visualization Page"))
   

    # UPLOAD
    if add_selectbox == 'Batch Prediction':
        upload_file = st.sidebar.file_uploader('Upload CSV File', type=["csv"])

        if upload_file is not None:
            st.subheader("RAW DATA")
            df = pd.read_csv(upload_file)

            # CLEAN UPLOADED FILE TO MATCH WITH THE MODEL FEATURES
            df.drop(['id','churn_prediction'],axis=1 ,inplace=True)
            st.write(df.shape)
            st.write(df.head(3))
            # drop same columns from test dataset
            df.drop(['state','total_day_charge','total_eve_charge','total_night_charge','total_intl_charge','number_vmail_messages'], axis=1, inplace=True)
            # Convert voice_mail_plan, international_plan to binary e.g. yes = 1 and no = 0:
            df['area_code'] = df['area_code'].map({'area_code_415':1, 'area_code_510':2, 'area_code_408':3})
            df['international_plan'] = df['international_plan'].map({'yes':1, 'no':0})
            df['voice_mail_plan'] = df['voice_mail_plan'].map({'yes':1, 'no':0}) 
            

            # Preprocessing – Scaling the features
            scaler = StandardScaler()
            df_sc = scaler.fit_transform(df)

            # Create prediction button
            submit = st.button('Make Prediction')

            st.write("---")
            st.subheader("VIEW PREDICTIONS")
            st.write("---")


            if submit:
                churn_pred = model.predict(df_sc)
                # Save the predicted values in CSV file
                ansRF = pd.read_csv('test.csv')
                ansRF.churn_prediction = churn_pred
                ansRF.churn_prediction= ansRF.churn_prediction.map({ 1: 'yes', 0 : 'no'}) 
                ansRF.to_csv('pred_test.csv', index=False)
                st.write(ansRF['churn_prediction'].value_counts())
                st.write(ansRF.head(750))
                with open('pred_test.csv') as f:
                    st.download_button('Download CSV', f)


    # INPUT CAPTURING
   
    # Getting input data from user

    if add_selectbox =='Online Prediction':
            st.sidebar.write("""### Slide to Fill""")
            account_length=st.sidebar.slider("1. Months a Customer Hold an Account :" , 0,250,0)
            area_code =st.sidebar.slider("2. Customer Area Code (_415= 1,_510= 2,_408= 3):" , 1,3,1)
            international_plan =st.sidebar.slider("3. Customer International Plan (0 = no & 1 = yes):" , 0,1,0)
            voice_mail_plan =st.sidebar.slider("4. Customer Voice Mail Plan (0 = no & 1 = yes):" , 0,1,0)
            total_day_minutes=st.sidebar.slider('5. Total Minutes of Day Calls :' , min_value=0, max_value=360, value=100)
            total_day_calls=st.sidebar.slider('6. Total Day Calls :' , min_value=0, max_value=200, value=50)
            total_eve_minutes=st.sidebar.slider('7. Total Minutes of Evening Calls :' , min_value=0, max_value=400, value=200)
            total_eve_calls=st.sidebar.slider('8. Total Number of Evening Calls :' , min_value=0, max_value=200, value=100)
            total_night_minutes=st.sidebar.slider('9. Total Minutes of Night Calls :' , min_value=0, max_value=400, value=200)
            total_night_calls=st.sidebar.slider('10. Total Number of Night Calls :' , min_value=0, max_value=200, value=100)
            total_intl_minutes=st.sidebar.slider('11. Total Minutes of International Calls :' , min_value=0, max_value=60, value=0)
            total_intl_calls=st.sidebar.slider('12. Total Number of International Calls :' , min_value=0, max_value=20, value=0)
            number_customer_service_calls=st.sidebar.slider('13. Number of Calls to Customer Service :' , min_value=0, max_value=10, value=0)


            input_dict = {
                'account_length': account_length,
                'area_code':area_code,
                'international_plan':international_plan,
                'voice_mail_plan':voice_mail_plan,
                'total_day_minutes':total_day_minutes,
                'total_day_calls':total_day_calls,
                'total_eve_minutes':total_eve_minutes,
                'total_eve_calls':total_eve_calls,
                'total_night_minutes':total_night_minutes,
                'total_night_calls':total_night_calls,
                'total_intl_minutes':total_intl_minutes,
                'total_intl_calls':total_intl_calls,
                'number_customer_service_calls':number_customer_service_calls

            }
            # Creating user dataframe
            input_df = pd.DataFrame(input_dict,index=[0])
            st.write(input_df)

            # Apply Feature Scalling 
            scaler = StandardScaler()
            user_data = scaler.fit_transform(input_df)

            if st.button("Predict"):
                    # Preprocessing – Scaling the features
                    output = model.predict(user_data)
                    if output == 0:
                        st.success("No, this customer is not willing to churn")
                    else:
                        st.success("Yes, this customer is willing to churn")
        
    if add_selectbox =='Visualization Page':
            st.subheader("VISUALIZATION OF TRAINING DATASET")
            train = pd.read_csv('train.csv')
           
                        
            st.write("""#### Table 1: Training DataFrame""")
            st.write(train.shape)
            st.write(train.head(4250))

            data = train["churn"].value_counts()

            fig1, ax1 = plt.subplots()
            ax1.pie(data, labels=data.index, autopct="%1.1f%%", shadow=True, startangle=90)
            ax1.axis("equal")  # Equal aspect ratio ensures that pie is drawn as a circle.

            st.write("""#### Figure 1: Customer Churn Distribution """)

            st.pyplot(fig1)
            
            st.write(""" ####  Figure 2: Bar Plot Analysis by Churn""")

            # We first review the 'Status' relation with categorical variables
            sns.set(font_scale=1.2)
            fig, axarr = plt.subplots(2, 2, figsize=(20, 13))
            sns.countplot(x = 'churn',data = train, ax=axarr[0][0])
            sns.countplot(x='area_code', hue = 'churn',data = train, ax=axarr[0][1])
            sns.countplot(x='international_plan', hue = 'churn',data = train, ax=axarr[1][0])
            sns.countplot(x='voice_mail_plan', hue = 'churn',data = train, ax=axarr[1][1])
            st.pyplot(fig)

            st.write(""" ####  Figure 3: Box Plot Analysis""")
            # BOX-POT with relation to Churn variable
            sns.set(font_scale=1.2)
            fig, axarr = plt.subplots(2, 2, figsize=(20, 13))
            sns.boxplot(x = 'churn', y = 'account_length', data = train, ax=axarr[0][0])
            sns.boxplot(x = 'churn', y = 'total_day_calls', data = train, ax=axarr[0][1])
            sns.boxplot(x = 'churn', y = 'total_eve_minutes', data = train, ax=axarr[1][0])
            sns.boxplot(x = 'churn', y = 'total_night_minutes', data = train, ax=axarr[1][1])
            st.pyplot(fig)


            st.write(""" ####  Figure 4: Histogram Analysis""")
            fig, axarr = plt.subplots(2, 2, figsize=(20, 13))
            sns.histplot(data = train, x = "total_night_minutes",  hue = "churn",ax=axarr[0][0])
            sns.histplot(data = train, x = "total_day_calls", hue = "churn",ax=axarr[0][1])
            sns.histplot(data = train, x = "total_eve_minutes",  hue = "churn",ax=axarr[1][0])
            sns.histplot(data = train, x = "account_length", hue = "churn",ax=axarr[1][1])
            st.pyplot(fig)


            st.write(""" ####  Figure 5: Scatter Plot Analysis """)
            fig = plt.figure(figsize=(17,15))
            plt.subplot(3,2,1)
            sns.scatterplot(data =train,x="account_length",y='total_day_minutes', hue="churn")
            plt.subplot(3,2,2)
            sns.scatterplot(data =train,x="total_day_minutes",y='total_day_calls', hue="churn")
            plt.subplot(3,2,3)
            sns.scatterplot(data =train,x="total_eve_calls",y='account_length', hue="churn")
            plt.subplot(3,2,4)
            sns.scatterplot(data =train,x="total_night_calls",y='total_day_calls', hue="churn")
            st.pyplot(fig)

            st.write(""" ####  Figure 6: Heatmanp Analysis """)

            fig, ax = plt.subplots(figsize=(20,10))
            sns.heatmap(train.corr(), cmap='viridis', annot = True, ax = ax)
            st.pyplot(fig)
            
            st.write(""" ####  Figure 7: Account Length by Number of Customer Service Calls """)

            data = train.groupby(["account_length"])["number_customer_service_calls"].mean().sort_values(ascending=True)
            plt.xlabel('number_customer_service_calls')
            st.line_chart(data)


        



if __name__ == '__main__':
	main()


